package vn.edu.likelion.springSecurityExercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityExerciseApplication.class, args);
	}

}
