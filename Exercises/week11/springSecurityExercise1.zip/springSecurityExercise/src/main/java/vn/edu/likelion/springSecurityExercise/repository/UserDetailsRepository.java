package vn.edu.likelion.springSecurityExercise.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.UserDetails;
import vn.edu.likelion.springSecurityExercise.entity.UserEntity;

public interface UserDetailsRepository extends JpaRepository<UserEntity, Integer> {
    UserEntity findByUsername(String username);
}
