package vn.edu.likelion.springSecurityExercise.controller;

public class LoginController {
}
