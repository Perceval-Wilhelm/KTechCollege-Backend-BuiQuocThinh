package vn.edu.likelion.springSecurityExercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
