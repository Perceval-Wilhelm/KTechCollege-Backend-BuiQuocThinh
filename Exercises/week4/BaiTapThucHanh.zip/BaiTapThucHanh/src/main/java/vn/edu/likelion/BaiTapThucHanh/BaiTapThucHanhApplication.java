package vn.edu.likelion.BaiTapThucHanh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaiTapThucHanhApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaiTapThucHanhApplication.class, args);
	}

}
