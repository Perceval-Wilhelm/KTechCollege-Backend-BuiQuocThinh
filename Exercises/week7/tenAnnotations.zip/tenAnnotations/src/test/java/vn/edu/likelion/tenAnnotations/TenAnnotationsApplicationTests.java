package vn.edu.likelion.tenAnnotations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TenAnnotationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
