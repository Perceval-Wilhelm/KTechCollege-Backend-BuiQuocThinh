package vn.edu.likelion.tenAnnotations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenAnnotationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TenAnnotationsApplication.class, args);
	}

}
