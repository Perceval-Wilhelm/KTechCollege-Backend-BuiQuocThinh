package vn.edu.likelion.assigment2jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assigment2jpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
