package vn.edu.likelion.assignment2jpa2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2jpa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
