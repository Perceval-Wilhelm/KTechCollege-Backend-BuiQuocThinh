package vn.edu.likelion.connectDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectDbApplication.class, args);
	}

}
