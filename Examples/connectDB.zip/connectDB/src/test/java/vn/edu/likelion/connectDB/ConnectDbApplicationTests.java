package vn.edu.likelion.connectDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
